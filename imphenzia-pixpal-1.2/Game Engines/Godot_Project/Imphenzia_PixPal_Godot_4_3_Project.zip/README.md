Thanks to Flynsarmy for making the Godot version of Imphenzia PixPal - original repo:
https://github.com/Flynsarmy/imphenzia-pixpal-godot-41-project


# Imphenzia PixPal Demo Scene for Godot 4

This repo contains a Godot version of the Imphenzia PixPal demo scene. Everything is working except the mirror which I don't believe Godot can do by default without the [mirror plugin](https://godotengine.org/asset-library/asset/1378).

![Screenshot of the demo scene running in Godot 4](https://github.com/Flynsarmy/imphenzia-pixpal-godot-41-project/blob/master/Assets/screenshot.png?raw=true)

## License

Creative Commons Zero v1.0 Universal
